import React, { useState, useEffect } from "react";

const fakeDB = { users: [], sessions: {} };

function App() {
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [logado, setLogado] = useState(false);
  const [saldo, setSaldo] = useState(0);
  const [creditoCompra, setCreditoCompra] = useState(0);
  const [mensagem, setMensagem] = useState("");
  const [girando, setGirando] = useState(false);
  const [premio, setPremio] = useState(null);
  const premios = [0, 1, 5, 10, 0.5, 2];

  const cadastrar = () => {
    if (fakeDB.users.find(u => u.email === email)) {
      setMensagem("Usuário já existe");
      return;
    }
    fakeDB.users.push({ email, senha, saldo: 0 });
    setMensagem("Cadastro realizado, faça login.");
  };

  const login = () => {
    const user = fakeDB.users.find(u => u.email === email && u.senha === senha);
    if (!user) {
      setMensagem("Login inválido");
      return;
    }
    fakeDB.sessions[email] = true;
    setLogado(true);
    setSaldo(user.saldo);
    setMensagem("Logado com sucesso");
  };

  const comprarCreditos = () => {
    if (creditoCompra <= 0) {
      setMensagem("Informe valor para comprar");
      return;
    }
    const user = fakeDB.users.find(u => u.email === email);
    user.saldo += creditoCompra;
    setSaldo(user.saldo);
    setMensagem(`Comprou R$${creditoCompra.toFixed(2)} em créditos!`);
    setCreditoCompra(0);
  };

  const girar = () => {
    if (girando) return;
    if (saldo < 1) {
      setMensagem("Saldo insuficiente");
      return;
    }
    setGirando(true);
    setSaldo(s => s - 1);

    setTimeout(() => {
      const premioValor = premios[Math.floor(Math.random() * premios.length)];
      if (premioValor > 0) {
        setSaldo(s => s + premioValor);
        setMensagem(`Parabéns! Você ganhou R$${premioValor.toFixed(2)}!`);
      } else {
        setMensagem("Que pena, não ganhou dessa vez.");
      }
      setPremio(premioValor);
      setGirando(false);
    }, 2500);
  };

  const pedirSaque = valor => {
    if (valor < 50) {
      setMensagem("Valor mínimo para saque é R$50");
      return;
    }
    if (valor > saldo) {
      setMensagem("Saldo insuficiente para saque");
      return;
    }
    // Simula processo de saque
    const user = fakeDB.users.find(u => u.email === email);
    user.saldo -= valor;
    setSaldo(user.saldo);
    setMensagem(`Pedido de saque de R$${valor.toFixed(2)} realizado!`);
  };

  if (!logado) {
    return (
      <div style={{ padding: 20 }}>
        <h2>Sorteio Cash</h2>
        <input placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} /><br />
        <input placeholder="Senha" type="password" value={senha} onChange={e => setSenha(e.target.value)} /><br />
        <button onClick={login}>Login</button>
        <button onClick={cadastrar}>Cadastrar</button>
        <p>{mensagem}</p>
      </div>
    );
  }

  return (
    <div style={{ padding: 20 }}>
      <h2>Bem-vindo ao Sorteio Cash</h2>
      <p>Saldo: R${saldo.toFixed(2)}</p>

      <div>
        <h3>Comprar Créditos</h3>
        <input type="number" value={creditoCompra} onChange={e => setCreditoCompra(Number(e.target.value))} />
        <button onClick={comprarCreditos}>Comprar</button>
      </div>

      <div style={{ marginTop: 20 }}>
        <h3>Girar a Roleta (1 crédito)</h3>
        <button disabled={girando || saldo < 1} onClick={girar}>
          {girando ? "Girando..." : "Girar"}
        </button>
        {premio !== null && <p>Último prêmio: R${premio.toFixed(2)}</p>}
      </div>

      <div style={{ marginTop: 20 }}>
        <h3>Saque</h3>
        <button onClick={() => pedirSaque(50)}>Pedir saque mínimo R$50</button>
      </div>

      <p>{mensagem}</p>
    </div>
  );
}

export default App;